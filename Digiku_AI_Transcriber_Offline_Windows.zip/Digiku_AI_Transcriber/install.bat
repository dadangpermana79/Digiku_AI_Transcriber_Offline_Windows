@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
echo ==============================================
echo  DIGIKU AI Transcriber - Instalasi (Windows)
echo ==============================================
echo.

REM --- 1. Cek Python ---
set "PY="
where python >nul 2>nul && set "PY=python"
if not defined PY where py >nul 2>nul && set "PY=py"
if not defined PY (
    echo [X] Python tidak ditemukan.
    echo     Instal Python 3.11 dari https://www.python.org/downloads/
    echo     dan centang "Add Python to PATH" saat instalasi.
    pause
    exit /b 1
)
echo [OK] Python terdeteksi. Versi:
%PY% --version

REM --- 2. Buat virtual environment ---
if not exist .venv (
    echo [..] Membuat virtual environment (.venv)...
    %PY% -m venv .venv
    if errorlevel 1 (
        echo [X] Gagal membuat virtual environment.
        pause
        exit /b 1
    )
) else (
    echo [OK] .venv sudah ada.
)

REM --- 3. Install dependensi ---
call .venv\Scripts\activate.bat
echo [..] Menginstal dependensi (bisa memakan waktu beberapa menit)...
python -m pip install --upgrade pip >nul
pip install -r requirements.txt
if errorlevel 1 (
    echo [X] Gagal menginstal dependensi. Periksa koneksi internet.
    pause
    exit /b 1
)
echo [OK] Dependensi terpasang.

REM --- 4. Cek FFmpeg ---
where ffmpeg >nul 2>nul
if errorlevel 1 (
    echo [X] FFmpeg TIDAK ditemukan di PATH.
    echo     Cara cepat:  winget install Gyan.FFmpeg
    echo     atau unduh dari https://www.gyan.dev/ffmpeg/builds/
    echo     Lalu pastikan folder bin ffmpeg masuk ke PATH.
) else (
    echo [OK] FFmpeg ditemukan.
)

REM --- 5. Cek GPU NVIDIA ---
where nvidia-smi >nul 2>nul
if errorlevel 1 (
    echo [!] nvidia-smi tidak ditemukan. Akselerasi GPU (CUDA) mungkin tidak tersedia.
    echo     Aplikasi tetap bisa berjalan dengan CPU (start_cpu.bat).
) else (
    echo [OK] GPU NVIDIA terdeteksi:
    nvidia-smi --query-gpu=name,driver_version --format=csv,noheader
)

REM --- 6. Buat direktori ---
for %%d in (models uploads outputs logs data) do (
    if not exist %%d mkdir %%d
)
echo [OK] Direktori siap.

echo.
echo ==============================================
echo  Instalasi selesai.
echo  Langkah berikutnya:
echo    1) download_models.bat   - unduh model AI
echo    2) start.bat             - jalankan (auto GPU/CPU)
echo       start_cpu.bat         - paksa mode CPU
echo ==============================================
pause
