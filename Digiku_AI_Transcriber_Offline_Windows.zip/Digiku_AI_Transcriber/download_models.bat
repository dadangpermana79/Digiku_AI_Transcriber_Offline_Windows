@echo off
chcp 65001 >nul
call .venv\Scripts\activate.bat
if errorlevel 1 (
    echo [X] Virtual environment tidak ditemukan. Jalankan install.bat terlebih dahulu.
    pause
    exit /b 1
)
if "%~1"=="" (
    echo Mengunduh model default: small
    python download_models.py small
) else (
    echo Mengunduh model: %*
    python download_models.py %*
)
echo.
pause
