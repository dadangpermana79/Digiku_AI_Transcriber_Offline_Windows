@echo off
chcp 65001 >nul
echo Menghentikan DIGIKU AI Transcriber (proses pada port 8000)...
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }"
echo Selesai.
pause
