@echo off
chcp 65001 >nul
call .venv\Scripts\activate.bat
if errorlevel 1 (
    echo [X] Virtual environment tidak ditemukan. Jalankan install.bat terlebih dahulu.
    pause
    exit /b 1
)
python -c "import faster_whisper, fastapi, uvicorn" >nul 2>nul
if errorlevel 1 (
    echo [X] Dependensi belum lengkap. Jalankan install.bat.
    pause
    exit /b 1
)
echo ==============================================
echo  DIGIKU AI Transcriber - memulai (auto GPU/CPU)
echo  Buka http://127.0.0.1:8000 di browser.
echo  Tekan Ctrl+C untuk berhenti.
echo ==============================================
start /b cmd /c "timeout /t 3 >nul & start http://127.0.0.1:8000"
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
