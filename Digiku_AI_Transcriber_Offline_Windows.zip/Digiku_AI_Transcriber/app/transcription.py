"""Mesin transkripsi faster-whisper.

Import faster-whisper dilakukan secara lazy agar aplikasi tetap bisa
di-start (untuk diagnostik/API) walau model belum diunduh atau
faster-whisper belum terpasang.
"""
from __future__ import annotations

import threading
from typing import Any, Iterator, Optional

from . import config

MODEL_IDS = {
    "tiny": "Systran/faster-whisper-tiny",
    "base": "Systran/faster-whisper-base",
    "small": "Systran/faster-whisper-small",
    "medium": "Systran/faster-whisper-medium",
}


class TranscriptionError(RuntimeError):
    """Error saat memuat model atau menjalankan inferensi."""


class TranscriptionEngine:
    def __init__(self) -> None:
        self._model: Any = None
        self._model_name: Optional[str] = None
        self._device: Optional[str] = None
        self._compute_type: Optional[str] = None
        self._lock = threading.Lock()

    @property
    def loaded_model(self) -> Optional[str]:
        return self._model_name

    def _load(self, model_name: str, device: str, compute_type: str) -> None:
        with self._lock:
            if (
                self._model is not None
                and self._model_name == model_name
                and self._device == device
                and self._compute_type == compute_type
            ):
                return
            try:
                from faster_whisper import WhisperModel  # noqa: F401
            except ImportError as e:
                raise TranscriptionError(
                    "faster-whisper belum terpasang. Jalankan install.bat terlebih dahulu."
                ) from e
            try:
                self._model = WhisperModel(
                    MODEL_IDS.get(model_name, model_name),
                    device=device,
                    compute_type=compute_type,
                    download_root=str(config.MODEL_DIR),
                )
            except Exception as e:
                raise TranscriptionError(
                    f"Gagal memuat model '{model_name}' pada {device}/{compute_type}: {e}"
                ) from e
            self._model_name = model_name
            self._device = device
            self._compute_type = compute_type

    def transcribe(
        self,
        audio_path,
        model_name: str,
        device: str,
        compute_type: str,
        language: Optional[str] = None,
        beam_size: int = 5,
        vad_filter: bool = True,
    ) -> tuple[dict, Iterator[dict]]:
        """Jalankan transkripsi. Kembalikan (meta, generator_segmen).

        meta berisi detected_language dan duration dari hasil inferensi.
        """
        self._load(model_name, device, compute_type)
        lang = None if language in (None, "", "auto") else language
        segments, info = self._model.transcribe(
            str(audio_path),
            language=lang,
            beam_size=int(beam_size),
            vad_filter=bool(vad_filter),
        )
        meta = {
            "detected_language": getattr(info, "language", None),
            "duration": float(getattr(info, "duration", 0.0) or 0.0),
        }

        def gen() -> Iterator[dict]:
            for seg in segments:
                yield {
                    "start": float(seg.start),
                    "end": float(seg.end),
                    "text": (seg.text or "").strip(),
                }

        return meta, gen()
