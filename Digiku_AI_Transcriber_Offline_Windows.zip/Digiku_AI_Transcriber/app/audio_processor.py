"""Validasi & inspeksi media menggunakan FFprobe/FFmpeg."""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path


class MediaError(Exception):
    """Error saat validasi/pemeriksaan media."""


def ffprobe_available() -> bool:
    return shutil.which("ffprobe") is not None


def ffmpeg_available() -> bool:
    return shutil.which("ffmpeg") is not None


def probe_media(path: Path) -> dict:
    """Kembalikan metadata media: duration, has_audio, format_name.

    Memvalidasi konten media sungguhan (bukan hanya ekstensi) lewat ffprobe.
    """
    if not ffprobe_available():
        raise MediaError(
            "ffprobe tidak ditemukan. Pastikan FFmpeg terpasang dan ada di PATH "
            "(lihat INSTALLATION_GUIDE.md)."
        )
    cmd = [
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration,format_name:stream=codec_type",
        "-of", "json", str(path),
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired as e:
        raise MediaError("Waktu pemeriksaan media habis (timeout 120 detik).") from e
    except OSError as e:
        raise MediaError(f"Gagal menjalankan ffprobe: {e}") from e

    if proc.returncode != 0:
        raise MediaError(f"File bukan media yang valid: {proc.stderr.strip()[:300]}")

    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError as e:
        raise MediaError("Gagal membaca metadata media dari ffprobe.") from e

    fmt = data.get("format", {})
    streams = data.get("streams", [])
    duration = float(fmt.get("duration", 0) or 0)
    has_audio = any(s.get("codec_type") == "audio" for s in streams)
    return {
        "duration": duration,
        "has_audio": has_audio,
        "format_name": fmt.get("format_name", ""),
    }
