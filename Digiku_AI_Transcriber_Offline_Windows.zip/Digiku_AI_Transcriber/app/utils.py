"""Utilitas umum: nama file aman, timestamp, ukuran, durasi."""
from __future__ import annotations

import re
import unicodedata
from pathlib import Path


def safe_filename(name: str, fallback: str = "file") -> str:
    """Bersihkan nama file agar aman (cegah path traversal & karakter ilegal)."""
    if not name:
        return fallback
    name = unicodedata.normalize("NFKD", name)
    name = name.encode("ascii", "ignore").decode("ascii", "ignore")
    name = re.sub(r"[^\w\-. ]", "_", name).strip(" .")
    name = re.sub(r"\s+", "_", name)
    if name in (".", "..") or "/" in name or "\\" in name or not name:
        return fallback
    return name[:200]


def safe_join(base: Path, *parts: str) -> Path:
    """Gabungkan path dan pastikan hasil tetap di dalam direktori base."""
    base_resolved = base.resolve()
    target = base_resolved.joinpath(*parts).resolve()
    if base_resolved != target and base_resolved not in target.parents:
        raise ValueError("Path di luar direktori yang diizinkan")
    return target


def format_srt_timestamp(seconds: float) -> str:
    ms = int(round(max(0.0, seconds) * 1000))
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def format_vtt_timestamp(seconds: float) -> str:
    ms = int(round(max(0.0, seconds) * 1000))
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"


def human_bytes(n: float) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024
    return f"{n:.1f} TB"


def human_duration(seconds: float) -> str:
    seconds = int(round(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}j {m}m {s}d"
    if m:
        return f"{m}m {s}d"
    return f"{s}d"
