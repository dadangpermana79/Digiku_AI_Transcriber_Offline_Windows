"""Manajemen job transkripsi: antrian, status, SQLite, worker thread.

Job diproses satu per satu di thread latar belakang (inferensi faster-whisper
melepaskan GIL karena backend C++), sehingga request HTTP tidak terblokir.
"""
from __future__ import annotations

import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator, Optional

from . import config
from .transcription import TranscriptionEngine

STATES = ("queued", "processing", "completed", "failed", "cancelled")

_ALLOWED_COLUMNS = {
    "status", "stage", "error", "progress", "started_at", "finished_at",
    "detected_language", "audio_duration",
}


class JobManager:
    def __init__(self, engine: TranscriptionEngine) -> None:
        self.engine = engine
        self._lock = threading.Lock()
        self._cancel_events: dict[str, threading.Event] = {}
        self._stop = threading.Event()
        config.ensure_dirs()
        self._init_db()
        self._worker = threading.Thread(
            target=self._worker_loop, name="transcriber-worker", daemon=True
        )
        self._worker.start()

    # ---- koneksi DB ----
    @contextmanager
    def _db(self) -> Iterator[sqlite3.Connection]:
        db = sqlite3.connect(config.DB_PATH, timeout=30)
        db.row_factory = sqlite3.Row
        try:
            yield db
            db.commit()
        finally:
            db.close()

    def _init_db(self) -> None:
        with self._db() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute(
                """CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY,
                    filename TEXT NOT NULL,
                    status TEXT NOT NULL,
                    language TEXT NOT NULL,
                    model TEXT NOT NULL,
                    device TEXT NOT NULL,
                    compute_type TEXT NOT NULL,
                    beam_size INTEGER DEFAULT 5,
                    vad_filter INTEGER DEFAULT 1,
                    audio_path TEXT,
                    audio_duration REAL,
                    detected_language TEXT,
                    created_at REAL,
                    started_at REAL,
                    finished_at REAL,
                    progress REAL DEFAULT 0,
                    stage TEXT DEFAULT '',
                    error TEXT
                )"""
            )
            db.execute(
                """CREATE TABLE IF NOT EXISTS segments (
                    job_id TEXT NOT NULL,
                    idx INTEGER NOT NULL,
                    start REAL,
                    end REAL,
                    text TEXT,
                    PRIMARY KEY (job_id, idx)
                )"""
            )

    # ---- CRUD ----
    def get_job(self, jid: str) -> Optional[dict]:
        with self._db() as db:
            row = db.execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
        return dict(row) if row else None

    def list_jobs(self, limit: int = 200) -> list[dict]:
        with self._db() as db:
            rows = db.execute(
                "SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    def create_job(
        self,
        filename: str,
        language: str,
        model: str,
        device: str,
        compute_type: str,
        audio_path: str,
        audio_duration: float,
        beam_size: int = 5,
        vad_filter: bool = True,
    ) -> str:
        jid = uuid.uuid4().hex
        now = time.time()
        with self._db() as db:
            db.execute(
                "INSERT INTO jobs (id, filename, status, language, model, device, "
                "compute_type, beam_size, vad_filter, audio_path, audio_duration, created_at) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (jid, filename, "queued", language, model, device, compute_type,
                 beam_size, int(vad_filter), audio_path, audio_duration, now),
            )
        return jid

    def _update(self, jid: str, **fields: Any) -> None:
        # keys berasal dari konstanta internal (daftar putih), bukan input user
        cols = [k for k in fields if k in _ALLOWED_COLUMNS]
        if not cols:
            return
        sets = ", ".join(f"{c}=?" for c in cols)
        with self._db() as db:
            db.execute(
                f"UPDATE jobs SET {sets} WHERE id=?",
                (*[fields[c] for c in cols], jid),
            )

    # ---- worker ----
    def _worker_loop(self) -> None:
        while not self._stop.is_set():
            job = self._next_queued()
            if job is None:
                time.sleep(0.5)
                continue
            self._process(job["id"])

    def _next_queued(self) -> Optional[dict]:
        with self._db() as db:
            row = db.execute(
                "SELECT id FROM jobs WHERE status='queued' ORDER BY created_at LIMIT 1"
            ).fetchone()
        return self.get_job(row["id"]) if row else None

    def _process(self, jid: str) -> None:
        job = self.get_job(jid)
        if not job:
            return
        cancel_event = threading.Event()
        with self._lock:
            self._cancel_events[jid] = cancel_event

        self._update(jid, status="processing", stage="memuat model", started_at=time.time())
        try:
            audio_path = job.get("audio_path")
            if not audio_path or not Path(audio_path).exists():
                raise RuntimeError("File audio tidak ditemukan di penyimpanan lokal.")

            meta, segs = self.engine.transcribe(
                audio_path,
                model_name=job["model"],
                device=job["device"],
                compute_type=job["compute_type"],
                language=job["language"],
                beam_size=job.get("beam_size") or config.BEAM_SIZE,
                vad_filter=bool(job.get("vad_filter", config.VAD_FILTER)),
            )

            self._update(
                jid,
                detected_language=meta.get("detected_language"),
                audio_duration=meta.get("duration"),
                stage="mentranskripsi",
            )
            total_dur = meta.get("duration") or job.get("audio_duration") or 0.0

            idx = 0
            for seg in segs:
                if cancel_event.is_set():
                    break
                idx += 1
                with self._db() as db:
                    db.execute(
                        "INSERT OR REPLACE INTO segments (job_id, idx, start, end, text) "
                        "VALUES (?,?,?,?,?)",
                        (jid, idx, seg["start"], seg["end"], seg["text"]),
                    )
                if total_dur > 0:
                    prog = min(100.0, seg["end"] / total_dur * 100.0)
                    self._update(jid, progress=prog)

            if cancel_event.is_set():
                self._update(jid, status="cancelled", finished_at=time.time(), stage="")
                self._cleanup_files(jid)
                return

            self._update(jid, stage="menyimpan hasil", progress=100.0)
            self._update(jid, status="completed", finished_at=time.time(), stage="", progress=100.0)
        except Exception as e:  # noqa: BLE001
            self._update(jid, status="failed", finished_at=time.time(), error=str(e), stage="")
        finally:
            with self._lock:
                self._cancel_events.pop(jid, None)

    # ---- cancel ----
    def cancel_job(self, jid: str) -> str:
        job = self.get_job(jid)
        if not job:
            return "not_found"
        if job["status"] in ("completed", "failed"):
            return "already_finished"
        if job["status"] == "queued":
            self._update(jid, status="cancelled", finished_at=time.time())
            self._cleanup_files(jid)
            return "cancelled"
        # processing
        with self._lock:
            ev = self._cancel_events.get(jid)
        if ev is not None:
            ev.set()
        self._update(jid, status="cancelled", finished_at=time.time())
        return "cancelled"

    def _cleanup_files(self, jid: str) -> None:
        job = self.get_job(jid)
        if job and job.get("audio_path"):
            p = Path(job["audio_path"])
            try:
                p.unlink(missing_ok=True)
            except OSError:
                pass

    # ---- segments ----
    def get_segments(self, jid: str) -> list[dict]:
        with self._db() as db:
            rows = db.execute(
                "SELECT idx, start, end, text FROM segments WHERE job_id=? ORDER BY idx",
                (jid,),
            ).fetchall()
        return [dict(r) for r in rows]

    def save_segments(self, jid: str, segments: list[dict]) -> None:
        with self._db() as db:
            db.execute("DELETE FROM segments WHERE job_id=?", (jid,))
            for i, seg in enumerate(segments, 1):
                db.execute(
                    "INSERT INTO segments (job_id, idx, start, end, text) VALUES (?,?,?,?,?)",
                    (jid, i, float(seg.get("start", 0)), float(seg.get("end", 0)),
                     str(seg.get("text", ""))),
                )

    # ---- delete ----
    def delete_job(self, jid: str) -> str:
        job = self.get_job(jid)
        if not job:
            return "not_found"
        self._cleanup_files(jid)
        with self._db() as db:
            db.execute("DELETE FROM segments WHERE job_id=?", (jid,))
            db.execute("DELETE FROM jobs WHERE id=?", (jid,))
        return "deleted"

    def shutdown(self) -> None:
        self._stop.set()
