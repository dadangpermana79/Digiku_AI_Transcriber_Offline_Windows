"""Konfigurasi aplikasi DIGIKU AI Transcriber.

Nilai dibaca dari environment variable (opsional melalui file .env di root).
Parser .env dibuat mandiri (tanpa dependensi eksternal).
"""
from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


_load_dotenv(BASE_DIR / ".env")


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on", "y")


# ---- Jaringan ----
HOST = os.environ.get("HOST", "127.0.0.1")
PORT = _int("PORT", 8000)

# ---- Upload ----
MAX_UPLOAD_MB = _int("MAX_UPLOAD_MB", 200)
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024
MAX_DURATION_SECONDS = _int("MAX_DURATION_SECONDS", 9000)  # 2 jam 30 menit

# ---- Direktori ----
MODEL_DIR = Path(os.environ.get("MODEL_DIR", str(BASE_DIR / "models")))
UPLOAD_DIR = Path(os.environ.get("UPLOAD_DIR", str(BASE_DIR / "uploads")))
OUTPUT_DIR = Path(os.environ.get("OUTPUT_DIR", str(BASE_DIR / "outputs")))
DATA_DIR = Path(os.environ.get("DATA_DIR", str(BASE_DIR / "data")))
LOG_DIR = Path(os.environ.get("LOG_DIR", str(BASE_DIR / "logs")))
DB_PATH = DATA_DIR / "jobs.sqlite3"

# ---- Model / inferensi ----
DEFAULT_MODEL = os.environ.get("DEFAULT_MODEL", "small")
DEFAULT_LANGUAGE = os.environ.get("DEFAULT_LANGUAGE", "auto")
DEFAULT_DEVICE = os.environ.get("DEFAULT_DEVICE", "auto")  # auto|cuda|cpu
DEFAULT_COMPUTE_TYPE = os.environ.get("DEFAULT_COMPUTE_TYPE", "auto")  # auto|float16|int8|int8_float16
BEAM_SIZE = _int("BEAM_SIZE", 5)
VAD_FILTER = _bool("VAD_FILTER", True)

SUPPORTED_MODELS = ["tiny", "base", "small", "medium"]
SUPPORTED_LANGUAGES = ["auto", "id", "en"]
SUPPORTED_FORMATS = {
    ".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".wma",
    ".mp4", ".mov", ".mkv", ".webm",
}

# ---- Retensi ----
RETENTION_HOURS = _int("RETENTION_HOURS", 0)  # 0 = simpan selamanya


def ensure_dirs() -> None:
    for d in (MODEL_DIR, UPLOAD_DIR, OUTPUT_DIR, DATA_DIR, LOG_DIR):
        d.mkdir(parents=True, exist_ok=True)
