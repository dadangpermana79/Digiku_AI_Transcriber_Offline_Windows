"""Ekspor transkrip ke TXT, SRT, dan VTT (UTF-8)."""
from __future__ import annotations

from typing import Iterable, Mapping

from .utils import format_srt_timestamp, format_vtt_timestamp


def _clean(text: str) -> str:
    return (text or "").strip()


def to_txt(segments: Iterable[Mapping], with_timestamps: bool = False) -> str:
    lines: list[str] = []
    for seg in segments:
        text = _clean(str(seg.get("text", "")))
        if not text:
            continue
        if with_timestamps:
            start = format_vtt_timestamp(float(seg.get("start", 0)))
            end = format_vtt_timestamp(float(seg.get("end", 0)))
            lines.append(f"[{start} -> {end}] {text}")
        else:
            lines.append(text)
    return "\n".join(lines) + ("\n" if lines else "")


def to_srt(segments: Iterable[Mapping]) -> str:
    blocks: list[str] = []
    i = 0
    for seg in segments:
        text = _clean(str(seg.get("text", "")))
        if not text:
            continue
        i += 1
        start = format_srt_timestamp(float(seg.get("start", 0)))
        end = format_srt_timestamp(float(seg.get("end", 0)))
        blocks.append(f"{i}\n{start} --> {end}\n{text}")
    return "\n\n".join(blocks) + ("\n" if blocks else "")


def to_vtt(segments: Iterable[Mapping]) -> str:
    lines: list[str] = ["WEBVTT", ""]
    for seg in segments:
        text = _clean(str(seg.get("text", "")))
        if not text:
            continue
        start = format_vtt_timestamp(float(seg.get("start", 0)))
        end = format_vtt_timestamp(float(seg.get("end", 0)))
        lines.append(f"{start} --> {end}")
        lines.append(text)
        lines.append("")
    return "\n".join(lines)
