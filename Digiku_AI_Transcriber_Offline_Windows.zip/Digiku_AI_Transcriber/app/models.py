"""Skema Pydantic untuk request & response API."""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class Segment(BaseModel):
    index: int = Field(..., ge=0)
    start: float = Field(..., ge=0)
    end: float = Field(..., ge=0)
    text: str = ""


class JobResponse(BaseModel):
    id: str
    filename: str
    status: str
    language: str
    model: str
    device: str = ""
    compute_type: str = ""
    beam_size: Optional[int] = None
    vad_filter: Optional[bool] = None
    audio_duration: Optional[float] = None
    detected_language: Optional[str] = None
    created_at: float
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    progress: float = 0.0
    stage: str = ""
    error: Optional[str] = None


class SegmentsUpdate(BaseModel):
    segments: list[Segment]


class HealthResponse(BaseModel):
    status: str
    version: str
    ffmpeg: bool
    ffprobe: bool
    model_loaded: bool
