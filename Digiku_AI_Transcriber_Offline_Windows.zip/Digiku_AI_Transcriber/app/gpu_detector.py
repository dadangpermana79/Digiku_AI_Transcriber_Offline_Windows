"""Deteksi dan diagnostik GPU (CUDA) melalui CTranslate2."""
from __future__ import annotations

from typing import Any


def detect_gpu() -> dict[str, Any]:
    """Kembalikan status CUDA, nama GPU, device dan compute type yang direkomendasikan."""
    info: dict[str, Any] = {
        "cuda_available": False,
        "device": "cpu",
        "gpu_name": None,
        "gpu_count": 0,
        "compute_type": "int8",
        "error": None,
        "ctranslate2_version": None,
    }
    try:
        import ctranslate2  # noqa: F401
        info["ctranslate2_version"] = getattr(ctranslate2, "__version__", "unknown")
    except ImportError as e:
        info["error"] = f"ctranslate2 tidak terpasang: {e}"
        return info

    try:
        count = ctranslate2.get_cuda_device_count()
        info["gpu_count"] = int(count)
        if count > 0:
            info["cuda_available"] = True
            info["device"] = "cuda"
            info["compute_type"] = "float16"
            try:
                info["gpu_name"] = ctranslate2.get_cuda_device_name(0)
            except Exception as e:  # pragma: no cover
                info["gpu_name"] = f"CUDA ({count} device) terdeteksi; nama gagal dibaca: {e}"
        else:
            info["error"] = "Tidak ada GPU CUDA yang terdeteksi (get_cuda_device_count = 0)."
    except Exception as e:  # pragma: no cover
        info["error"] = f"Gagal inisialisasi CUDA: {e}"

    return info


def resolve_device(requested: str = "auto") -> tuple[str, str]:
    """Tentukan (device, compute_type) berdasarkan preferensi user + deteksi GPU.

    Return juga informasi GPU agar API bisa menampilkan diagnostik.
    """
    gpu = detect_gpu()

    if requested == "cpu":
        return "cpu", "int8"
    if requested == "cuda":
        if gpu["cuda_available"]:
            return "cuda", "float16"
        # Jangan fallback diam-diam; tandai error dan serahkan ke caller untuk memberi tahu user.
        return "cpu", "int8"
    # auto
    if gpu["cuda_available"]:
        return "cuda", "float16"
    return "cpu", "int8"


def resolve_compute_type(compute_type: str, device: str) -> str:
    """Sesuaikan compute type dengan device (auto -> float16 di GPU, int8 di CPU)."""
    if compute_type == "auto":
        return "float16" if device == "cuda" else "int8"
    if compute_type == "float16" and device == "cpu":
        # float16 tidak didukung baik di CPU murni; gunakan int8 agar aman.
        return "int8"
    return compute_type
