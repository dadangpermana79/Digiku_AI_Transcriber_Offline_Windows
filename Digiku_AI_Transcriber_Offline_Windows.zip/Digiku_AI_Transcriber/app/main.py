"""FastAPI application — DIGIKU AI Transcriber (Offline Windows Edition)."""
from __future__ import annotations

import time
import uuid
from pathlib import Path

from contextlib import asynccontextmanager

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles

from . import __version__, config
from .audio_processor import (
    MediaError,
    ffmpeg_available,
    ffprobe_available,
    probe_media,
)
from .exporters import to_srt, to_txt, to_vtt
from .gpu_detector import detect_gpu, resolve_compute_type, resolve_device
from .job_manager import JobManager
from .models import HealthResponse, JobResponse, SegmentsUpdate
from .transcription import TranscriptionEngine
from .utils import safe_filename

config.ensure_dirs()

engine = TranscriptionEngine()
manager = JobManager(engine)

@asynccontextmanager
async def lifespan(_app: FastAPI):
    yield
    manager.shutdown()


app = FastAPI(title="DIGIKU AI Transcriber", version=__version__, docs_url="/api/docs", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=str(config.BASE_DIR / "static")), name="static")


def _public_job(job: dict | None) -> dict | None:
    if not job:
        return None
    keys = (
        "id", "filename", "status", "language", "model", "device", "compute_type",
        "beam_size", "vad_filter", "audio_duration", "detected_language", "created_at", "started_at",
        "finished_at", "progress", "stage", "error",
    )
    return {k: job.get(k) for k in keys}


@app.get("/")
def index() -> FileResponse:
    return FileResponse(str(config.BASE_DIR / "static" / "index.html"))


@app.get("/api/health", response_model=HealthResponse)
def health() -> dict:
    return {
        "status": "ok",
        "version": __version__,
        "ffmpeg": ffmpeg_available(),
        "ffprobe": ffprobe_available(),
        "model_loaded": engine.loaded_model is not None,
    }


@app.get("/api/system")
def system() -> dict:
    gpu = detect_gpu()
    device, _ = resolve_device(config.DEFAULT_DEVICE)
    return {
        "version": __version__,
        "gpu": gpu,
        "default_device": device,
        "default_compute_type": resolve_compute_type(config.DEFAULT_COMPUTE_TYPE, device),
        "default_model": config.DEFAULT_MODEL,
        "loaded_model": engine.loaded_model,
        "max_upload_mb": config.MAX_UPLOAD_MB,
        "max_duration_seconds": config.MAX_DURATION_SECONDS,
        "supported_models": config.SUPPORTED_MODELS,
        "supported_languages": config.SUPPORTED_LANGUAGES,
        "supported_formats": sorted(config.SUPPORTED_FORMATS),
    }


@app.get("/api/models")
def list_models() -> dict:
    out = []
    for m in config.SUPPORTED_MODELS:
        cache = config.MODEL_DIR / f"models--Systran--faster-whisper-{m}"
        out.append({"name": m, "downloaded": cache.exists()})
    return {"models": out, "model_dir": str(config.MODEL_DIR)}


@app.post("/api/jobs", response_model=JobResponse)
async def create_job(
    file: UploadFile = File(...),
    language: str = Form("auto"),
    model: str = Form("small"),
    device: str = Form("auto"),
    compute_type: str = Form("auto"),
    beam_size: int = Form(config.BEAM_SIZE),
    vad_filter: bool = Form(config.VAD_FILTER),
) -> dict:
    if model not in config.SUPPORTED_MODELS:
        raise HTTPException(400, f"Model tidak didukung. Pilih salah satu: {config.SUPPORTED_MODELS}")
    if language not in config.SUPPORTED_LANGUAGES:
        raise HTTPException(400, f"Bahasa tidak didukung. Pilih: {config.SUPPORTED_LANGUAGES}")
    if device not in ("auto", "cuda", "cpu"):
        raise HTTPException(400, "Parameter device harus auto|cuda|cpu")
    if compute_type not in ("auto", "float16", "int8", "int8_float16"):
        raise HTTPException(400, "Parameter compute_type tidak valid")
    if not 1 <= beam_size <= 10:
        raise HTTPException(400, "beam_size harus antara 1 dan 10")

    original = file.filename or "upload"
    ext = Path(original).suffix.lower()
    if ext not in config.SUPPORTED_FORMATS:
        raise HTTPException(
            400, f"Format file '{ext}' tidak didukung. Didukung: {sorted(config.SUPPORTED_FORMATS)}"
        )

    # tentukan device & compute type (auto/cuda/cpu)
    resolved_device, _ = resolve_device(device)
    resolved_ct = resolve_compute_type(compute_type, resolved_device)

    # stream file ke disk (tanpa memuat seluruh isi ke RAM)
    tmp_id = uuid.uuid4().hex
    dest = config.UPLOAD_DIR / f"{tmp_id}{ext}"
    size = 0
    try:
        with dest.open("wb") as f:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > config.MAX_UPLOAD_BYTES:
                    raise HTTPException(413, f"Ukuran file melebihi batas {config.MAX_UPLOAD_MB} MB")
                f.write(chunk)
        if size == 0:
            raise HTTPException(400, "File kosong")
    except HTTPException:
        dest.unlink(missing_ok=True)
        raise
    except Exception as e:
        dest.unlink(missing_ok=True)
        raise HTTPException(500, f"Gagal menyimpan upload: {e}") from e

    # validasi konten media sungguhan (bukan hanya ekstensi)
    try:
        meta = probe_media(dest)
    except MediaError as e:
        dest.unlink(missing_ok=True)
        raise HTTPException(400, str(e)) from e
    if not meta["has_audio"]:
        dest.unlink(missing_ok=True)
        raise HTTPException(400, "File tidak mengandung stream audio.")
    if meta["duration"] > config.MAX_DURATION_SECONDS:
        h = config.MAX_DURATION_SECONDS // 3600
        m = (config.MAX_DURATION_SECONDS % 3600) // 60
        dest.unlink(missing_ok=True)
        raise HTTPException(
            400, f"Durasi {meta['duration']:.0f} detik melebihi batas {h} jam {m} menit"
        )

    jid = manager.create_job(
        filename=original,
        language=language,
        model=model,
        device=resolved_device,
        compute_type=resolved_ct,
        audio_path=str(dest),
        audio_duration=meta["duration"],
        beam_size=beam_size,
        vad_filter=vad_filter,
    )
    return _public_job(manager.get_job(jid))


@app.get("/api/jobs", response_model=list[JobResponse])
def list_jobs() -> list[dict]:
    return [_public_job(j) for j in manager.list_jobs()]


@app.get("/api/jobs/{jid}", response_model=JobResponse)
def get_job(jid: str) -> dict:
    job = manager.get_job(jid)
    if not job:
        raise HTTPException(404, "Job tidak ditemukan")
    return _public_job(job)


@app.post("/api/jobs/{jid}/cancel", response_model=JobResponse)
def cancel_job(jid: str) -> dict:
    result = manager.cancel_job(jid)
    if result == "not_found":
        raise HTTPException(404, "Job tidak ditemukan")
    if result == "already_finished":
        raise HTTPException(409, "Job sudah selesai, tidak dapat dibatalkan")
    return _public_job(manager.get_job(jid))


@app.get("/api/jobs/{jid}/segments")
def get_segments(jid: str) -> dict:
    job = manager.get_job(jid)
    if not job:
        raise HTTPException(404, "Job tidak ditemukan")
    segs = manager.get_segments(jid)
    return {
        "segments": [
            {"index": i, "start": s["start"], "end": s["end"], "text": s["text"]}
            for i, s in enumerate(segs)
        ]
    }


@app.put("/api/jobs/{jid}/segments")
def put_segments(jid: str, payload: SegmentsUpdate) -> dict:
    job = manager.get_job(jid)
    if not job:
        raise HTTPException(404, "Job tidak ditemukan")
    if job["status"] != "completed":
        raise HTTPException(409, "Hanya transkrip yang selesai yang dapat diedit")
    segs = [{"start": s.start, "end": s.end, "text": s.text} for s in payload.segments]
    manager.save_segments(jid, segs)
    return {"ok": True, "count": len(segs)}


@app.get("/api/jobs/{jid}/export/{fmt}")
def export_job(jid: str, fmt: str) -> Response:
    if fmt not in ("txt", "srt", "vtt"):
        raise HTTPException(404, "Format ekspor harus txt|srt|vtt")
    job = manager.get_job(jid)
    if not job:
        raise HTTPException(404, "Job tidak ditemukan")
    if job["status"] != "completed":
        raise HTTPException(409, "Transkripsi belum selesai")
    segs = manager.get_segments(jid)
    if fmt == "txt":
        content = to_txt(segs)
    elif fmt == "srt":
        content = to_srt(segs)
    else:
        content = to_vtt(segs)
    base = safe_filename(Path(job["filename"]).stem, "transcript")
    filename = f"transcript-{base}.{fmt}"
    return Response(
        content=content,
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.delete("/api/jobs/{jid}")
def delete_job(jid: str) -> dict:
    result = manager.delete_job(jid)
    if result == "not_found":
        raise HTTPException(404, "Job tidak ditemukan")
    return {"ok": True}
