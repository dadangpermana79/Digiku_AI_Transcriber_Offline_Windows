/* DIGIKU AI Transcriber — frontend logic */
'use strict';

const $ = (id) => document.getElementById(id);

let selectedFile = null;
let activeJobId = null;
let currentSegments = [];
let pollTimer = null;
let elapsedTimer = null;
let jobStartedAt = null;
let systemInfo = null;

const SUPPORTED_EXTS = ['.mp3','.wav','.m4a','.aac','.flac','.ogg','.wma','.mp4','.mov','.mkv','.webm'];

/* ---------- util ---------- */
function toast(msg, ms = 3200) {
  const t = $('toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(t._t);
  t._t = setTimeout(() => { t.hidden = true; }, ms);
}
function fmtBytes(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}
function fmtDur(sec) {
  sec = Math.max(0, Math.round(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return (h ? h + 'j ' : '') + (m ? m + 'm ' : '') + s + 'd';
}
function fmtTime(ts) {
  if (!ts) return '—';
  const d = new Date(ts * 1000);
  return d.toLocaleString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
async function api(path, opts = {}) {
  const res = await fetch(path, opts);
  let body = null;
  try { body = await res.json(); } catch (e) { /* noop */ }
  if (!res.ok) {
    const detail = body && body.detail ? body.detail : (res.status + ' ' + res.statusText);
    const err = new Error(detail);
    err.status = res.status;
    throw err;
  }
  return body;
}

/* ---------- system info ---------- */
async function loadSystem() {
  try {
    const [sys, health] = await Promise.all([api('/api/system'), api('/api/health')]);
    systemInfo = sys;

    // device pill
    const pill = $('device-pill');
    const g = sys.gpu || {};
    if (g.cuda_available) {
      pill.textContent = '⚡ GPU: ' + (g.gpu_name || 'CUDA') + ' (float16)';
      pill.className = 'pill pill-info';
    } else {
      pill.textContent = '💻 CPU (int8)';
      pill.className = 'pill pill-warn';
      pill.title = g.error || 'CUDA tidak tersedia';
    }

    // limits
    $('dz-limits').textContent =
      'Maks. ' + sys.max_upload_mb + ' MB · ' + fmtDur(sys.max_duration_seconds);

    // disable cuda option if unavailable
    const devSel = $('device-select');
    const cudaOpt = devSel.querySelector('option[value="cuda"]');
    if (cudaOpt) {
      if (!g.cuda_available) {
        cudaOpt.disabled = true;
        cudaOpt.textContent = 'GPU (CUDA) — tidak tersedia';
      } else {
        cudaOpt.textContent = 'GPU (CUDA) — ' + (g.gpu_name || 'CUDA');
      }
    }

    // offline pill from health (ffmpeg presence)
    const off = $('offline-pill');
    if (!health.ffmpeg || !health.ffprobe) {
      off.textContent = '⚠ FFMPEG TIDAK TERDETEKSI';
      off.className = 'pill pill-warn';
    }

    // model download status
    try {
      const models = await api('/api/models');
      for (const m of models.models) {
        const opt = $('model-select').querySelector('option[value="' + m.name + '"]');
        if (opt && !m.downloaded) opt.textContent += ' (belum diunduh)';
      }
    } catch (e) { /* non-fatal */ }
  } catch (e) {
    toast('Gagal memuat info sistem: ' + e.message);
  }
}

/* ---------- upload ---------- */
function setupUpload() {
  const dz = $('dropzone');
  const input = $('file-input');
  $('browse-btn').addEventListener('click', (e) => { e.stopPropagation(); input.click(); });
  dz.addEventListener('click', () => input.click());
  input.addEventListener('change', () => {
    if (input.files.length) onFileSelected(input.files[0]);
  });
  ['dragenter', 'dragover'].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove('drag'); }));
  dz.addEventListener('drop', (e) => {
    if (e.dataTransfer.files.length) onFileSelected(e.dataTransfer.files[0]);
  });
  $('fi-clear').addEventListener('click', () => { selectedFile = null; $('file-info').hidden = true; input.value = ''; });
}

function onFileSelected(file) {
  const ext = '.' + (file.name.split('.').pop() || '').toLowerCase();
  if (!SUPPORTED_EXTS.includes(ext)) {
    toast('Format tidak didukung: ' + ext);
    return;
  }
  if (systemInfo && file.size > systemInfo.max_upload_mb * 1024 * 1024) {
    toast('Ukuran melebihi batas ' + systemInfo.max_upload_mb + ' MB');
    return;
  }
  selectedFile = file;
  $('fi-name').textContent = file.name;
  $('fi-meta').textContent = fmtBytes(file.size);
  $('file-info').hidden = false;
}

/* ---------- start / cancel ---------- */
async function startJob() {
  if (!selectedFile) { toast('Pilih file terlebih dahulu.'); return; }
  if (activeJobId) { toast('Masih ada proses berjalan.'); return; }

  const fd = new FormData();
  fd.append('file', selectedFile);
  fd.append('language', $('lang-select').value);
  fd.append('model', $('model-select').value);
  fd.append('device', $('device-select').value);
  fd.append('compute_type', 'auto');
  fd.append('beam_size', $('beam-size').value);
  fd.append('vad_filter', $('vad-filter').checked ? 'true' : 'false');

  $('start-btn').disabled = true;
  $('process-status').hidden = false;
  $('stage-label').textContent = 'Mengunggah…';
  setProgress(0, '');
  try {
    const job = await api('/api/jobs', { method: 'POST', body: fd });
    activeJobId = job.id;
    jobStartedAt = job.created_at;
    $('cancel-btn').hidden = false;
    startElapsed();
    pollJob();
  } catch (e) {
    $('start-btn').disabled = false;
    $('process-status').hidden = true;
    toast('Upload gagal: ' + e.message);
  }
}

async function cancelJob() {
  if (!activeJobId) return;
  try {
    await api('/api/jobs/' + activeJobId + '/cancel', { method: 'POST' });
    toast('Membatalkan…');
  } catch (e) {
    toast('Gagal membatalkan: ' + e.message);
  }
}

function setProgress(pct, stage) {
  $('progress-fill').style.width = Math.max(0, Math.min(100, pct)) + '%';
  $('stage-label').textContent = stage || '—';
  $('progress-pct').textContent = pct > 0 ? Math.round(pct) + '%' : '';
}

function startElapsed() {
  clearInterval(elapsedTimer);
  const tick = () => {
    if (!jobStartedAt) return;
    $('elapsed-label').textContent = 'Waktu berjalan: ' + fmtDur((Date.now() / 1000) - jobStartedAt);
  };
  tick();
  elapsedTimer = setInterval(tick, 1000);
}

async function pollJob() {
  clearInterval(pollTimer);
  pollTimer = setInterval(async () => {
    if (!activeJobId) { clearInterval(pollTimer); return; }
    let job;
    try { job = await api('/api/jobs/' + activeJobId); }
    catch (e) { clearInterval(pollTimer); toast('Gagal membaca status: ' + e.message); return; }

    if (job.started_at) jobStartedAt = job.started_at;
    setProgress(job.progress || 0, stageLabel(job));

    if (job.status === 'completed') {
      clearInterval(pollTimer);
      clearInterval(elapsedTimer);
      setProgress(100, 'Selesai');
      $('elapsed-label').textContent = 'Selesai dalam ' + fmtDur((job.finished_at || Date.now()/1000) - job.started_at);
      $('start-btn').disabled = false;
      $('cancel-btn').hidden = true;
      toast('Transkripsi selesai ✓');
      await loadSegments(job.id);
      await loadHistory();
    } else if (job.status === 'failed') {
      clearInterval(pollTimer);
      clearInterval(elapsedTimer);
      $('start-btn').disabled = false;
      $('cancel-btn').hidden = true;
      $('stage-label').textContent = 'Gagal';
      toast('Transkripsi gagal: ' + (job.error || 'error tak dikenal'));
      activeJobId = null;
      await loadHistory();
    } else if (job.status === 'cancelled') {
      clearInterval(pollTimer);
      clearInterval(elapsedTimer);
      $('start-btn').disabled = false;
      $('cancel-btn').hidden = true;
      $('stage-label').textContent = 'Dibatalkan';
      toast('Proses dibatalkan.');
      activeJobId = null;
      await loadHistory();
    }
  }, 1500);
}

function stageLabel(job) {
  if (job.status === 'queued') return 'Antrean…';
  if (job.status === 'processing') return job.stage || 'Memproses…';
  if (job.status === 'completed') return 'Selesai';
  if (job.status === 'failed') return 'Gagal';
  if (job.status === 'cancelled') return 'Dibatalkan';
  return job.status;
}

/* ---------- editor ---------- */
async function loadSegments(jid) {
  try {
    const data = await api('/api/jobs/' + jid + '/segments');
    currentSegments = data.segments;
    renderSegments(currentSegments);
    enableExports(jid);
  } catch (e) {
    toast('Gagal memuat transkrip: ' + e.message);
  }
}

function renderSegments(segs) {
  const wrap = $('segments');
  const empty = $('editor-empty');
  if (!segs || !segs.length) {
    wrap.hidden = true; empty.hidden = false; return;
  }
  empty.hidden = true;
  wrap.hidden = false;
  wrap.innerHTML = '';
  segs.forEach((seg) => {
    const div = document.createElement('div');
    div.className = 'seg';
    div.dataset.text = (seg.text || '').toLowerCase();
    const time = document.createElement('div');
    time.className = 'seg-time';
    time.textContent = ts(seg.start) + ' → ' + ts(seg.end);
    const ta = document.createElement('textarea');
    ta.value = seg.text || '';
    div.appendChild(time);
    div.appendChild(ta);
    wrap.appendChild(div);
  });
}

function ts(s) {
  const ms = Math.round(s * 1000);
  const h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000),
        sec = Math.floor((ms % 60000) / 1000), milli = ms % 1000;
  const pad = (n, w = 2) => String(n).padStart(w, '0');
  return pad(h) + ':' + pad(m) + ':' + pad(sec) + ',' + pad(milli, 3);
}

async function saveEdits() {
  if (!activeJobId) { toast('Tidak ada transkrip aktif.'); return; }
  const tas = $('segments').querySelectorAll('textarea');
  const segs = currentSegments.map((seg, i) => ({
    index: i, start: seg.start, end: seg.end, text: tas[i] ? tas[i].value : seg.text,
  }));
  try {
    const r = await api('/api/jobs/' + activeJobId + '/segments', {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ segments: segs }),
    });
    toast('Edit tersimpan ✓ (' + r.count + ' segmen)');
  } catch (e) {
    toast('Gagal menyimpan edit: ' + e.message);
  }
}

async function copyAll() {
  const tas = $('segments').querySelectorAll('textarea');
  const text = Array.from(tas).map((t) => t.value.trim()).filter(Boolean).join('\n\n');
  try {
    await navigator.clipboard.writeText(text);
    toast('Teks disalin ✓');
  } catch (e) {
    toast('Tidak dapat menyalin ke clipboard.');
  }
}

function enableExports(jid) {
  $('dl-txt').href = '/api/jobs/' + jid + '/export/txt';
  $('dl-srt').href = '/api/jobs/' + jid + '/export/srt';
  $('dl-vtt').href = '/api/jobs/' + jid + '/export/vtt';
  ['dl-txt','dl-srt','dl-vtt'].forEach((id) => $(id).setAttribute('data-disabled', '0'));
}

function searchTranscript(q) {
  const items = $('segments').querySelectorAll('.seg');
  items.forEach((el) => {
    const hit = !q || el.dataset.text.includes(q);
    el.hidden = !hit;
    el.classList.toggle('hit', !!(q && hit && q.length > 1));
  });
}

/* ---------- history ---------- */
async function loadHistory() {
  try {
    const jobs = await api('/api/jobs');
    renderHistory(jobs);
  } catch (e) {
    toast('Gagal memuat riwayat: ' + e.message);
  }
}

function renderHistory(jobs) {
  const list = $('history-list');
  const empty = $('history-empty');
  if (!jobs.length) { list.innerHTML = ''; empty.hidden = false; return; }
  empty.hidden = true;
  list.innerHTML = '';
  jobs.forEach((job) => {
    const item = document.createElement('div');
    item.className = 'history-item';
    const main = document.createElement('div');
    main.className = 'h-main';
    const name = document.createElement('div');
    name.className = 'h-name';
    name.textContent = job.filename;
    const meta = document.createElement('div');
    meta.className = 'h-meta';
    meta.textContent = fmtTime(job.created_at) + ' · ' + job.model + ' · ' +
      (job.device === 'cuda' ? 'GPU' : 'CPU') + ' · durasi audio ' +
      (job.audio_duration ? fmtDur(job.audio_duration) : '—');
    main.appendChild(name); main.appendChild(meta);

    const badge = document.createElement('span');
    badge.className = 'badge ' + job.status;
    badge.textContent = job.status;

    const actions = document.createElement('div');
    actions.className = 'h-actions';
    if (job.status === 'completed') {
      const open = document.createElement('button');
      open.textContent = 'Buka';
      open.addEventListener('click', () => reopenJob(job.id));
      actions.appendChild(open);
    }
    const del = document.createElement('button');
    del.textContent = 'Hapus';
    del.className = 'del';
    del.addEventListener('click', () => deleteJob(job.id));
    actions.appendChild(del);

    item.appendChild(main); item.appendChild(badge); item.appendChild(actions);
    list.appendChild(item);
  });
}

async function reopenJob(jid) {
  activeJobId = jid;
  const job = await api('/api/jobs/' + jid);
  await loadSegments(jid);
  $('editor-card').scrollIntoView({ behavior: 'smooth' });
  toast('Membuka transkrip: ' + job.filename);
}

async function deleteJob(jid) {
  if (!confirm('Hapus job ini beserta transkripnya?')) return;
  try {
    await api('/api/jobs/' + jid, { method: 'DELETE' });
    if (activeJobId === jid) {
      activeJobId = null; currentSegments = [];
      $('segments').innerHTML = ''; $('segments').hidden = true; $('editor-empty').hidden = false;
      ['dl-txt','dl-srt','dl-vtt'].forEach((id) => $(id).setAttribute('data-disabled', '1'));
    }
    toast('Job dihapus.');
    await loadHistory();
  } catch (e) {
    toast('Gagal menghapus: ' + e.message);
  }
}

/* ---------- events ---------- */
function setupEvents() {
  setupUpload();
  $('start-btn').addEventListener('click', startJob);
  $('cancel-btn').addEventListener('click', cancelJob);
  $('save-edits').addEventListener('click', saveEdits);
  $('copy-btn').addEventListener('click', copyAll);
  $('search-input').addEventListener('input', (e) => searchTranscript(e.target.value.toLowerCase()));
  $('export-card').querySelectorAll('.export-btn').forEach((a) =>
    a.addEventListener('click', (e) => { if (a.dataset.disabled === '1') e.preventDefault(); }));
  // refresh riwayat berkala
  setInterval(loadHistory, 15000);
}

/* ---------- boot ---------- */
document.addEventListener('DOMContentLoaded', () => {
  setupEvents();
  loadSystem();
  loadHistory();
});
