"""Unduh model Whisper (lokal) untuk DIGIKU AI Transcriber.

Penggunaan:
    python download_models.py small
    python download_models.py tiny base small medium
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

MODEL_IDS = {
    "tiny": "Systran/faster-whisper-tiny",
    "base": "Systran/faster-whisper-base",
    "small": "Systran/faster-whisper-small",
    "medium": "Systran/faster-whisper-medium",
}


def main() -> int:
    parser = argparse.ArgumentParser(description="Unduh model Whisper ke direktori lokal")
    parser.add_argument(
        "models", nargs="*", default=["small"],
        help="Nama model: tiny/base/small/medium (default: small)",
    )
    parser.add_argument(
        "--model-dir", default=str(Path(__file__).resolve().parent / "models"),
        help="Direktori penyimpanan model",
    )
    args = parser.parse_args()

    model_dir = Path(args.model_dir)
    model_dir.mkdir(parents=True, exist_ok=True)

    try:
        from faster_whisper import WhisperModel  # noqa: F401
    except ImportError:
        print("ERROR: faster-whisper belum terpasang. Jalankan install.bat terlebih dahulu.")
        return 1

    ok = True
    for m in args.models:
        if m not in MODEL_IDS:
            print(f"[lewati] Model tidak dikenal: '{m}'. Pilih: {list(MODEL_IDS)}")
            ok = False
            continue
        print(f"-> Mengunduh model '{m}' ({MODEL_IDS[m]}) ke {model_dir} ...")
        try:
            # Instansiasi memicu unduhan + verifikasi bahwa model bisa dimuat.
            WhisperModel(
                MODEL_IDS[m], device="cpu", compute_type="int8",
                download_root=str(model_dir),
            )
            print(f"   [OK] '{m}' siap digunakan.")
        except Exception as e:  # noqa: BLE001
            print(f"   [X] Gagal mengunduh '{m}': {e}")
            ok = False

    print("Selesai." if ok else "Selesai (dengan kesalahan).")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
