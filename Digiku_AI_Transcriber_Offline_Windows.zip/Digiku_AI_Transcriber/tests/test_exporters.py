"""Tes format ekspor TXT/SRT/VTT dan timestamp."""
from app.exporters import to_srt, to_txt, to_vtt
from app.utils import format_srt_timestamp, format_vtt_timestamp

SEGS = [
    {"start": 0.0, "end": 1.5, "text": "Halo dunia"},
    {"start": 1.5, "end": 3.0, "text": "Selamat pagi"},
]


def test_srt_timestamp():
    assert format_srt_timestamp(0.0) == "00:00:00,000"
    assert format_srt_timestamp(3661.5) == "01:01:01,500"
    assert format_srt_timestamp(1.5) == "00:00:01,500"


def test_vtt_timestamp():
    assert format_vtt_timestamp(0.0) == "00:00:00.000"
    assert format_vtt_timestamp(3661.5) == "01:01:01.500"


def test_to_srt():
    out = to_srt(SEGS)
    assert out.startswith("1\n00:00:00,000 --> 00:00:01,500\nHalo dunia")
    assert "2\n00:00:01,500 --> 00:00:03,000\nSelamat pagi" in out


def test_to_vtt():
    out = to_vtt(SEGS)
    assert out.startswith("WEBVTT\n\n")
    assert "00:00:00.000 --> 00:00:01.500" in out
    assert "Halo dunia" in out


def test_to_txt():
    out = to_txt(SEGS)
    assert "Halo dunia" in out
    assert "Selamat pagi" in out
    assert "00:00:" not in out  # tanpa timestamp


def test_to_txt_with_timestamps():
    out = to_txt(SEGS, with_timestamps=True)
    assert "[00:00:00.000 -> 00:00:01.500] Halo dunia" in out


def test_utf8_preserved():
    segs = [{"start": 0.0, "end": 1.0, "text": "Selamat datang, Bapak/Ibu."}]
    assert "Bapak/Ibu" in to_txt(segs)
