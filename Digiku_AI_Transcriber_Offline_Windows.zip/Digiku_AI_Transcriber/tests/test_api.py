"""Tes API (FastAPI TestClient) — engine & probe di-mock."""
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

import app.main as main_mod

client = TestClient(main_mod.app)


def test_health():
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert "ffprobe" in body


def test_system():
    r = client.get("/api/system")
    assert r.status_code == 200
    body = r.json()
    assert "gpu" in body
    assert body["max_upload_mb"] == 200
    assert "small" in body["supported_models"]


def test_models():
    r = client.get("/api/models")
    assert r.status_code == 200
    names = [m["name"] for m in r.json()["models"]]
    assert names == ["tiny", "base", "small", "medium"]


def test_upload_unsupported_format():
    files = {"file": ("malware.exe", b"MZ", "application/octet-stream")}
    r = client.post("/api/jobs", files=files, data={"language": "auto", "model": "small", "device": "cpu"})
    assert r.status_code == 400


def test_upload_empty_file():
    files = {"file": ("empty.mp3", b"", "audio/mpeg")}
    r = client.post("/api/jobs", files=files, data={"language": "auto", "model": "small", "device": "cpu"})
    assert r.status_code == 400


def test_upload_oversized(monkeypatch):
    monkeypatch.setattr("app.config.MAX_UPLOAD_BYTES", 10)
    files = {"file": ("big.mp3", b"x" * 100, "audio/mpeg")}
    r = client.post("/api/jobs", files=files, data={"language": "auto", "model": "small", "device": "cpu"})
    assert r.status_code == 413


def test_upload_invalid_model():
    files = {"file": ("a.mp3", b"xx", "audio/mpeg")}
    r = client.post("/api/jobs", files=files, data={"language": "auto", "model": "huge", "device": "cpu"})
    assert r.status_code == 400


def test_missing_ffprobe(monkeypatch):
    from app.audio_processor import MediaError, probe_media
    monkeypatch.setattr("app.audio_processor.ffprobe_available", lambda: False)
    with pytest.raises(MediaError):
        probe_media(Path("x.mp3"))


def test_job_lifecycle_and_export(monkeypatch):
    # mock probe_media (validasi media lolos tanpa ffprobe nyata)
    monkeypatch.setattr(
        main_mod, "probe_media",
        lambda path: {"duration": 5.0, "has_audio": True, "format_name": "wav"},
    )
    # mock engine transcribe
    segs_data = [
        {"start": 0.0, "end": 2.0, "text": "Halo dunia"},
        {"start": 2.0, "end": 5.0, "text": "Ini transkrip"},
    ]
    monkeypatch.setattr(
        main_mod.engine, "transcribe",
        lambda *a, **kw: ({"detected_language": "id", "duration": 5.0}, iter(segs_data)),
    )

    files = {"file": ("test.wav", b"\x00\x00" * 100, "audio/wav")}
    r = client.post("/api/jobs", files=files, data={
        "language": "auto", "model": "small", "device": "cpu",
        "compute_type": "int8", "beam_size": "5", "vad_filter": "true",
    })
    assert r.status_code == 200, r.text
    jid = r.json()["id"]

    status = None
    for _ in range(100):
        time.sleep(0.1)
        jr = client.get(f"/api/jobs/{jid}").json()
        status = jr["status"]
        if status in ("completed", "failed"):
            break
    assert status == "completed", f"status akhir: {status}"

    sr = client.get(f"/api/jobs/{jid}/segments")
    assert sr.status_code == 200
    assert len(sr.json()["segments"]) == 2

    er = client.get(f"/api/jobs/{jid}/export/srt")
    assert er.status_code == 200
    assert "Halo dunia" in er.text

    # hapus
    dr = client.delete(f"/api/jobs/{jid}")
    assert dr.status_code == 200
    assert client.get(f"/api/jobs/{jid}").status_code == 404
