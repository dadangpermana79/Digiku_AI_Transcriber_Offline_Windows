"""Konfigurasi pytest: isolasi direktori runtime ke temp + paksa CPU."""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

_tmp = Path(tempfile.mkdtemp(prefix="digiku-test-"))
os.environ["DATA_DIR"] = str(_tmp / "data")
os.environ["UPLOAD_DIR"] = str(_tmp / "uploads")
os.environ["OUTPUT_DIR"] = str(_tmp / "outputs")
os.environ["MODEL_DIR"] = str(_tmp / "models")
os.environ["LOG_DIR"] = str(_tmp / "logs")
os.environ["DEFAULT_DEVICE"] = "cpu"
os.environ["DEFAULT_COMPUTE_TYPE"] = "int8"
