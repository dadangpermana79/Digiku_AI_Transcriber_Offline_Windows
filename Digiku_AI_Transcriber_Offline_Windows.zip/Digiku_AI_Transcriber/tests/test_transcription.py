"""Tes mesin transkripsi (faster-whisper di-mock)."""
import sys
from unittest.mock import MagicMock, patch

import pytest

from app.transcription import TranscriptionEngine, TranscriptionError


class FakeSegment:
    def __init__(self, start, end, text):
        self.start = start
        self.end = end
        self.text = text


class FakeInfo:
    language = "id"
    duration = 10.0


class FakeModel:
    def __init__(self, *a, **kw):
        pass

    def transcribe(self, path, language=None, beam_size=5, vad_filter=True):
        segs = iter([FakeSegment(0, 2, "halo"), FakeSegment(2, 4, "dunia")])
        return segs, FakeInfo()


def _patch_faster_whisper(factory):
    return patch.dict(sys.modules, {"faster_whisper": MagicMock(WhisperModel=factory)})


def test_engine_transcribe_yields_segments():
    engine = TranscriptionEngine()
    with _patch_faster_whisper(FakeModel):
        meta, segs = engine.transcribe("x.mp3", "small", "cpu", "int8", language="id")
    assert meta["detected_language"] == "id"
    assert meta["duration"] == 10.0
    seg_list = list(segs)
    assert seg_list[0]["text"] == "halo"
    assert seg_list[1]["start"] == 2.0


def test_engine_missing_module_raises():
    engine = TranscriptionEngine()

    def fake_import(name, *a, **kw):
        if name == "faster_whisper":
            raise ImportError("no faster_whisper")
        return __import__(name, *a, **kw)

    with patch("builtins.__import__", side_effect=fake_import):
        with pytest.raises(TranscriptionError) as ei:
            engine.transcribe("x.mp3", "small", "cpu", "int8")
    assert "faster-whisper" in str(ei.value)


def test_engine_model_load_error():
    class FailingModel:
        def __init__(self, *a, **kw):
            raise RuntimeError("model 'small' tidak ditemukan")

    engine = TranscriptionEngine()
    with _patch_faster_whisper(FailingModel):
        with pytest.raises(TranscriptionError) as ei:
            engine.transcribe("x.mp3", "small", "cpu", "int8")
    assert "small" in str(ei.value)


def test_engine_caches_loaded_model():
    engine = TranscriptionEngine()
    calls = []

    class CountingModel(FakeModel):
        def __init__(self, *a, **kw):
            super().__init__(*a, **kw)
            calls.append(1)

    with _patch_faster_whisper(CountingModel):
        engine.transcribe("x.mp3", "small", "cpu", "int8")
        engine.transcribe("x.mp3", "small", "cpu", "int8")  # harus pakai cache
    assert len(calls) == 1
