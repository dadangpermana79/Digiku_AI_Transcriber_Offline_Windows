"""Tes validasi: nama file aman, path traversal, format, GPU/compute."""
from pathlib import Path

import pytest

from app import config
from app.gpu_detector import resolve_compute_type, resolve_device
from app.utils import safe_filename, safe_join


def test_safe_filename_strips_traversal():
    out = safe_filename("../etc/passwd")
    assert ".." not in out
    assert "/" not in out
    assert "\\" not in out


def test_safe_filename_slashes():
    assert safe_filename("a/b") == "a_b"


def test_safe_filename_empty():
    assert safe_filename("") == "file"


def test_safe_join_blocks_escape():
    base = Path("/tmp/digiku-base")
    with pytest.raises(ValueError):
        safe_join(base, "../escape.txt")


def test_supported_formats():
    for ext in (".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".wma",
                ".mp4", ".mov", ".mkv", ".webm"):
        assert ext in config.SUPPORTED_FORMATS
    assert ".exe" not in config.SUPPORTED_FORMATS
    assert ".txt" not in config.SUPPORTED_FORMATS


def test_supported_models():
    assert config.SUPPORTED_MODELS == ["tiny", "base", "small", "medium"]


def test_resolve_device_cpu():
    assert resolve_device("cpu") == ("cpu", "int8")


def test_resolve_compute_type():
    assert resolve_compute_type("auto", "cpu") == "int8"
    assert resolve_compute_type("auto", "cuda") == "float16"
    assert resolve_compute_type("float16", "cpu") == "int8"
    assert resolve_compute_type("int8", "cuda") == "int8"


def test_gpu_unavailable_detection(monkeypatch):
    from app import gpu_detector
    monkeypatch.setattr(
        gpu_detector, "detect_gpu",
        lambda: {"cuda_available": False, "device": "cpu", "compute_type": "int8",
                 "gpu_name": None, "gpu_count": 0, "error": "tidak ada GPU",
                 "ctranslate2_version": "x"},
    )
    assert resolve_device("auto") == ("cpu", "int8")
