@echo off
chcp 65001 >nul
call .venv\Scripts\activate.bat
if errorlevel 1 (
    echo [X] Virtual environment tidak ditemukan. Jalankan install.bat terlebih dahulu.
    pause
    exit /b 1
)
echo ==============================================
echo  DIGIKU AI Transcriber - memulai (MODE CPU / int8)
echo  Buka http://127.0.0.1:8000 di browser.
echo  Tekan Ctrl+C untuk berhenti.
echo ==============================================
set DEFAULT_DEVICE=cpu
set DEFAULT_COMPUTE_TYPE=int8
start /b cmd /c "timeout /t 3 >nul & start http://127.0.0.1:8000"
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
